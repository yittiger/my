(function (global) {
  global.__MY_CONFIG__ = {
    
    // 接口服务
    API_HOST: 'http://127.0.0.1:8080'
  }

})(window)
